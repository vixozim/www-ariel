jQuery(document).ready(function(){

	jQuery('ul.top-menu').superfish();

});
